# Week 1 Log
- Topic selected
- Roles assigned
- Started Dijkstra implementation