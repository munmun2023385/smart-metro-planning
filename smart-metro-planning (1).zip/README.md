# Smart Metro Planning using Dijkstra and Prim's Algorithm

This project simulates a metro rail network using Dijkstra's algorithm for shortest path routing and Prim's algorithm for cost-effective network construction.

## Team Members
- Humera
- Samriddhi
- Muskaan
- Mansha

## Structure
- Dijkstra and Prim implementations are in `metro_graph/`
- Sample input/output in `input_output/`
- Progress logs in `team_logs/`
- Report and Presentation in respective folders

## How to Run
```bash
python metro_graph/dijkstra.py
python metro_graph/prim.py
```

## Sample Graph:
A-B (5), A-C (3), B-D (2), C-D (7)

## Output
- Shortest Path: A -> B -> D
- MST: A-B, A-C, B-D
