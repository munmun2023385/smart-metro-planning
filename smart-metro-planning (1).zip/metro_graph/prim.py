# Prim's Algorithm Implementation
import heapq

def prim(graph, start):
    visited = set()
    min_edges = [(0, start, None)]
    mst = []

    while min_edges:
        cost, node, prev = heapq.heappop(min_edges)
        if node not in visited:
            visited.add(node)
            if prev:
                mst.append((prev, node, cost))
            for neighbor, weight in graph[node]:
                if neighbor not in visited:
                    heapq.heappush(min_edges, (weight, neighbor, node))
    return mst

# Example usage
graph = {
    'A': [('B', 5), ('C', 3)],
    'B': [('A', 5), ('D', 2)],
    'C': [('A', 3), ('D', 7)],
    'D': [('B', 2), ('C', 7)]
}

print("Minimum Spanning Tree:", prim(graph, 'A'))
