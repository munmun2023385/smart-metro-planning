
# Smart Metro Planning Project

## Algorithms Used:
- Dijkstra's Algorithm for shortest path (Samriddhi)
- Prim's Algorithm for minimum spanning tree (Muskaan)

## Python Code Example

```python
import heapq

# Dijkstra's Algorithm
def dijkstra(graph, start):
    distances = {vertex: float('infinity') for vertex in graph}
    distances[start] = 0
    pq = [(0, start)]
    while pq:
        current_distance, current_vertex = heapq.heappop(pq)
        if current_distance > distances[current_vertex]:
            continue
        for neighbor, weight in graph[current_vertex].items():
            distance = current_distance + weight
            if distance < distances[neighbor]:
                distances[neighbor] = distance
                heapq.heappush(pq, (distance, neighbor))
    return distances

# Prim's Algorithm
def prim(graph):
    visited = set()
    start_node = list(graph.keys())[0]
    visited.add(start_node)
    edges = [(cost, start_node, to) for to, cost in graph[start_node].items()]
    heapq.heapify(edges)
    mst = []
    while edges:
        cost, frm, to = heapq.heappop(edges)
        if to not in visited:
            visited.add(to)
            mst.append((frm, to, cost))
            for to_next, cost_next in graph[to].items():
                if to_next not in visited:
                    heapq.heappush(edges, (cost_next, to, to_next))
    return mst
```

## Input/Output available in input_output folder.
